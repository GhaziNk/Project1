public class AddressBookApplication {

    public static void main(String[] args) {
        // Create an object of AddressBook
        AddressBook addressBook=new AddressBook();
        //Call initAddressBookExercise
        addressBook.initAddressBookExercise();
    }

}