class Menu {

//functions to print prompts for particular fields

//function to prompt for first name

    public static void prompt_FirstName() {

        System.out.println("Ghazi");

    }

//function to prompt for last name

    public static void prompt_LastName() {

        System.out.println("Noseir");

    }

//function to prompt for street

    public static void prompt_Street() {

        System.out.println("6745 leona creek");

    }

//function to prompt for city

    public static void prompt_City() {

        System.out.println("Oakland");

    }

//function to prompt for state

    public static void prompt_State() {

        System.out.println("CA");

    }

//function to prompt for zip

    public static void prompt_Zip() {

        System.out.println("94621");

    }

//function to prompt for telephone

    public static void prompt_Telephone() {

        System.out.println("5102282139");

    }

//function to prompt for email

    public static void prompt_Email() {

    }

}

